%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%     Minimax Regret in Practice - Four Examples on Treatment Choice    %%
%%                             Matlab Code                               %%
%%              by Patrick Eozenou, Javier Rivas and Karl Schlag         %%
%%                       2006 - Copyrights reserved                      %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; clc; close;
%Load the data from a .mat file
%-----Treatment 1
      load('C:\Documents and Settings\Administrator\Desktop\Israel.mat');
%-----Treatment 2
      load('C:\Documents and Settings\Administrator\Desktop\Japan.mat');

treatments = who;
%Name the treatments given the variable names
treatment_1 = Israel(:,1);
treatment_2 = Japan(:,1);

%Maximum and minimum theoretical interval for the value of the variables
lower_interval = 0;
upper_interval = 10;

%Binomial Average Rule or Paired Sample? (0=BAR, 1=PS)
method = 0;

%Correlated rule? (0=no, 1=yes)
VA_trick = 0;

%Accuracy of the result (even number, 4 yields about two decimals accuracy)
accuracy = 4;

%Unitary cost of implementing each treatment
cost_1 = 0;
cost_2 = 0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[probability_of_choosing_treatment_1,probability_of_choosing_treatment_2] = f_program(treatments, ...
     treatment_1, treatment_2, lower_interval, upper_interval, method, VA_trick, accuracy, cost_1, cost_2);